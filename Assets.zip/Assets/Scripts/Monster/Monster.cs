public class Monster
{
    private MonsterData _data;
    private int _hp;
    private Room _currentPosition;
    private State _state;

    public Monster(MonsterData data)
    {
        _data = data;
        _hp = _data.MaxHp;
    }
}
