using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Room
{
    [SerializeField] private RoomData _roomData;

    private bool _hasTreasure;
    private List<Resource> _resources;
    private int _TrapCount;

    public Room(RoomData data)
    {
        _roomData = data;
    }
}
