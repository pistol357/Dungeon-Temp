using UnityEngine;

public class MonsterActionState : IState
{
    private TurnManager _turnManager;
    private Clan _currentClan;
    private int _activeMonsterIndex;

    public MonsterActionState(TurnManager turnManager)
    {
        _turnManager = turnManager;
    }

    public void Enter()
    {
        _currentClan = _turnManager.CurrentTurnClan;
        _activeMonsterIndex = 0;
    }

    public void Execute()
    {
        if (_turnManager.CurrentRound == 0)
        {
            StartRound();
        }
    }

    public void Exit()
    {
        _turnManager.EndMonsterActionState();
    }

    private void StartRound()
    {
        _currentClan.InitSummon();
    }

    private void SelectCard()
    {

    }

    private void MonsterAction()
    {
        if(_currentClan.ActiveMonsterCount == 0)
        {
            Debug.Log($"행동 가능한 몬스터 없음");
            return;
        }
    }
}
